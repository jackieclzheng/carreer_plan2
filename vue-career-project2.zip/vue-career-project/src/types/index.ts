export interface Career {
  id: number;
  title: string;
  description: string;
  requiredSkills: string[];
  averageSalary: string;
}
